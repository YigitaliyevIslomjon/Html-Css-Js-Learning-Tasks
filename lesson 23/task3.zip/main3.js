var gm = {carname:"Nexia", price:["$5000","$9000","$10000"], position:[1,2,3]};
var gm2 = {carname:"Malibu", price:["$13000","$17000","$22000"], position:[1,2,3]};
var gm3 = {carname:"Captiva", price:["$12500","$16000","$20000"], position:[1,2,3]};


console.log(gm.carname + " " + gm.price[0] + " " + gm.position[0]);
console.log(gm.carname + " " + gm.price[1] + " "+ gm.position[1]);

console.log(gm.carname + " " + gm.price[2] + " " + gm.position[2]);
console.log(gm2.carname + " " + gm2.price[0] +  " " + gm2.position[0]);
console.log(gm2.carname + " " + gm2.price[1] + " " + gm2.position[1]);
console.log(gm2.carname + " " + gm2.price[2] + " " + gm2.position[2]);
console.log(gm3.carname + " " + gm3.price[0] + " " + gm3.position[0]);
console.log(gm3.carname + " " + gm3.price[1] + " " + gm3.position[1]);
console.log(gm3.carname + " " + gm3.price[2] + " " + gm3.position[2]);