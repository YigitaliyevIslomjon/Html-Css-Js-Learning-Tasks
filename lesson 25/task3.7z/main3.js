var massiv = ["olma","davlat","xalq","dasturchi","dasturlash","xalq","google","boolean"];

console.log(massiv);
console.log("qiymatni kiriting !! funksiyanomi = findword() ");


var findword = function(a){
	for(var i in massiv){

		if( massiv[i] === a){
			console.log(a);
			console.log(i + " - chi indeksdagi");
			
		}		
	}
}