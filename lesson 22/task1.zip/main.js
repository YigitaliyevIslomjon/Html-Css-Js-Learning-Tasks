var a = Math.random()*100;
 a = parseInt(a);
 console.log("a soning qiymati = " + a)
if(a != 0){

if ( (a%2) == 0){
	console.log("a soni just son");
}
else if( (a%2) == 1){
	console.log("a soni toq son");
}
}
else{
	console.log("0 juft son emas")
}


