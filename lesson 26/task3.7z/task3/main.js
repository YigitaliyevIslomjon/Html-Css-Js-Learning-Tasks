function fuu(){
	var a = document.getElementById("input1").value;
	var b = document.getElementById("input2").value;

	document.getElementById("bk1").style.width = a;
	document.getElementById("bk1").style.height = b;

}