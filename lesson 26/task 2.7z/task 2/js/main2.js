function fuu()
{
	var a  = document.getElementById("one").value;

	var b = a.length;
	console.log(b);

	if (b == 0){
		document.getElementById("too").style.width = "0px";
	}
	else if( b == 1 ){
		
	}
	else if( b == 2 ){
		document.getElementById("too").style.width = "54px";
	}
	else if( b == 3 ){
		document.getElementById("too").style.width = "81px";
	}
	else if(b == 4 ){
		document.getElementById("too").style.width = "108px";
	}
	else if( b == 5){
		document.getElementById("too").style.width = "135px";
	}
	else if(b == 6 ){
		document.getElementById("too").style.width = "162px";
	}
	else if( b == 7 ){
		document.getElementById("too").style.width = "189px";
	}
	else if( b == 8){
		document.getElementById("too").style.width = "216px";
	}
	else if( b == 9){
		document.getElementById("too").style.width = "243px";
	}
	else if( b == 10){
		document.getElementById("too").style.width = "270px";
	}
	else if( b == 11){
		document.getElementById("too").style.width = "297px";
	}
	else if( b == 12){
		document.getElementById("too").style.width = "324px";
	}

	if( b == 0){
		document.getElementById("text1").innerHTML = "";
	}
	else if( b <= 4){
		document.getElementById("text1").innerHTML = "Too week";
		document.getElementById("text1").style.color = "red";
		document.getElementById("too").style.borderBottom = "3px solid red";
	}
	else if( b <= 8 && b > 4){
		document.getElementById("text1").innerHTML = "Not Bad";
		document.getElementById("text1").style.color = "orange";
		document.getElementById("too").style.borderBottom = "3px solid orange";
	}
	else if( b <= 12 && b > 8){
		document.getElementById("text1").innerHTML = "Strong !";
		document.getElementById("text1").style.color = "green";
		document.getElementById("too").style.borderBottom = "3px solid green";
	}

}	
// 2 - funksiyam

function fuu2()
{
	var a  = document.getElementById("one2").value;

	var b = a.length;
	console.log(b);

	if (b == 0){
		document.getElementById("too2").style.width = "0px";
	}
	else if( b == 1 ){
		
	}
	else if( b == 2 ){
		document.getElementById("too2").style.width = "54px";
	}
	else if( b == 3 ){
		document.getElementById("too2").style.width = "81px";
	}
	else if(b == 4 ){
		document.getElementById("too2").style.width = "108px";
	}
	else if( b == 5){
		document.getElementById("too2").style.width = "135px";
	}
	else if(b == 6 ){
		document.getElementById("too2").style.width = "162px";
	}
	else if( b == 7 ){
		document.getElementById("too2").style.width = "189px";
	}
	else if( b == 8){
		document.getElementById("too2").style.width = "216px";
	}
	else if( b == 9){
		document.getElementById("too2").style.width = "243px";
	}
	else if( b == 10){
		document.getElementById("too2").style.width = "270px";
	}
	else if( b == 11){
		document.getElementById("too2").style.width = "297px";
	}
	else if( b == 12){
		document.getElementById("too2").style.width = "324px";
	}

	if( b == 0){
		document.getElementById("text2").innerHTML = "";
	}
	else if( b <= 4){
		document.getElementById("text2").innerHTML = "Too week";
		document.getElementById("text2").style.color = "red";
		document.getElementById("too2").style.borderBottom = "3px solid red";
	}
	else if( b <= 8 && b > 4){
		document.getElementById("text2").innerHTML = "Not Bad";
		document.getElementById("text2").style.color = "orange";
		document.getElementById("too2").style.borderBottom = "3px solid orange";
	}
	else if( b <= 12 && b > 8){
		document.getElementById("text2").innerHTML = "Strong !";
		document.getElementById("text2").style.color = "green";
		document.getElementById("too2").style.borderBottom = "3px solid green";
	}

}	



function fuu3()
{
	var a  = document.getElementById("one3").value;

	var b = a.length;
	console.log(b);

	if (b == 0){
		document.getElementById("too3").style.width = "0px";
	}
	else if( b == 1 ){
		
	}
	else if( b == 2 ){
		document.getElementById("too3").style.width = "54px";
	}
	else if( b == 3 ){
		document.getElementById("too3").style.width = "81px";
	}
	else if(b == 4 ){
		document.getElementById("too3").style.width = "108px";
	}
	else if( b == 5){
		document.getElementById("too3").style.width = "135px";
	}
	else if(b == 6 ){
		document.getElementById("too3").style.width = "162px";
	}
	else if( b == 7 ){
		document.getElementById("too3").style.width = "189px";
	}
	else if( b == 8){
		document.getElementById("too3").style.width = "216px";
	}
	else if( b == 9){
		document.getElementById("too3").style.width = "243px";
	}
	else if( b == 10){
		document.getElementById("too3").style.width = "270px";
	}
	else if( b == 11){
		document.getElementById("too3").style.width = "297px";
	}
	else if( b == 12){
		document.getElementById("too3").style.width = "324px";
	}

	if( b == 0){
		document.getElementById("text3").innerHTML = "";
	}
	else if( b <= 4){
		document.getElementById("text3").innerHTML = "Too week";
		document.getElementById("text3").style.color = "red";
		document.getElementById("too3").style.borderBottom = "3px solid red";
	}
	else if( b <= 8 && b > 4){
		document.getElementById("text3").innerHTML = "Not Bad";
		document.getElementById("text3").style.color = "orange";
		document.getElementById("too3").style.borderBottom = "3px solid orange";
	}
	else if( b <= 12 && b > 8){
		document.getElementById("text3").innerHTML = "Strong !";
		document.getElementById("text3").style.color = "green";
		document.getElementById("too3").style.borderBottom = "3px solid green";
	}

}	


function fuu4()
{
	var a  = document.getElementById("one4").value;

	var b = a.length;
	console.log(b);

	if (b == 0){
		document.getElementById("too4").style.width = "0px";
	}
	else if( b == 1 ){
		
	}
	else if( b == 2 ){
		document.getElementById("too4").style.width = "54px";
	}
	else if( b == 3 ){
		document.getElementById("too4").style.width = "81px";
	}
	else if(b == 4 ){
		document.getElementById("too4").style.width = "108px";
	}
	else if( b == 5){
		document.getElementById("too4").style.width = "135px";
	}
	else if(b == 6 ){
		document.getElementById("too4").style.width = "162px";
	}
	else if( b == 7 ){
		document.getElementById("too4").style.width = "189px";
	}
	else if( b == 8){
		document.getElementById("too4").style.width = "216px";
	}
	else if( b == 9){
		document.getElementById("too4").style.width = "243px";
	}
	else if( b == 10){
		document.getElementById("too4").style.width = "270px";
	}
	else if( b == 11){
		document.getElementById("too4").style.width = "297px";
	}
	else if( b == 12){
		document.getElementById("too4").style.width = "324px";
	}

	if( b == 0){
		document.getElementById("text4").innerHTML = "";
	}
	else if( b <= 4){
		document.getElementById("text4").innerHTML = "Too week";
		document.getElementById("text4").style.color = "red";
		document.getElementById("too4").style.borderBottom = "3px solid red";
	}
	else if( b <= 8 && b > 4){
		document.getElementById("text4").innerHTML = "Not Bad";
		document.getElementById("text4").style.color = "orange";
		document.getElementById("too4").style.borderBottom = "3px solid orange";
	}
	else if( b <= 12 && b > 8){
		document.getElementById("text4").innerHTML = "Strong !";
		document.getElementById("text4").style.color = "green";
		document.getElementById("too4").style.borderBottom = "3px solid green";
	}

}	



function  forxx(){
	document.getElementById("one3").value = "";
	document.getElementById("too3").style.width = "0px";
	document.getElementById("text3").innerHTML = "";
}

function  forxx2(){
	document.getElementById("one4").value = "";
	document.getElementById("too4").style.width = "0px";
	document.getElementById("text4").innerHTML = "";
}